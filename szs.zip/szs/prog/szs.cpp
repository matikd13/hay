#include <iostream>
#include <string>

using namespace std;

int main()
{
    int x;
    cin >> x;

    if (x==1)
    {
        cout<<"tak";
    }
    else
    {
        cout<<"nie";
    }

    return 0;
}
