#include <iostream>
#include <windows.h>
using namespace std;

/*
Logowanie z rejestracja v1
-Kod stworzony przez Mateusza Jakubowskiego
*/

int main()
{
    int a;
    string loginwer = "matikd";     //Loginy
    string loginwer1 = "gosc";
    string login;
    int haslo;
    int haslower = 123456;          //Hasla
    int temp = 1;
    while(temp){
    cout<<"1-Rejestracja 2-Logowanie"<<endl;
    cin>>a;

    if(a==2)
    {
        cout<< "Podaj Login: ";
        cin>> login;
        if(login == loginwer)
        {
            cout<<endl<< "Podaj Haslo: ";
            cin>> haslo;
            if(haslo == haslower)
            {
                //Wpisz co chcesz:
            for(int b=0;b>10000;b++)
            {
                {
                cout<<"111001011000101";
                }
            }
            }
            else
            {
                cout<<"Odmowa Dostepu";
            }
        }
        else if(loginwer1 == login)
        {
            cout<<"I co zrobisz?"<<endl<<endl;
            cout<<"nic nie zrobisz";
        }
        else
        {
            cout<<"Nie istnieje taki uzytkownik";
        }
    }
    else if(a == 1)
    {
        cout<<"Podaj nowy login: "<<endl;
        cin>>loginwer;
        cout<<"Podaj nowe haslo: "<<endl;
        cin>>haslower;

    }

    }
}
