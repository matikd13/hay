#include <iostream>
#include <cstring>

using namespace std;

int main()
{
    int a,b;
    string n;
    cin>>n;
    a = n.length();
    char tab2[a];
    strcpy(tab2, n.c_str());
    b=a-1;
    for(int i=0;i<=a;i++)
    {
        cout<<tab2[b];
        b--;
    }

    return 0;
}
