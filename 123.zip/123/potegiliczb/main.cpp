#include <iostream>

using namespace std;

int main()
{
    int n, a=2, i;
    cout<<"Podaj Liczb�: ";
    cin>>n;
    cout<<endl;
    cout<<"1"<<endl<<"2"<<endl;
    while(a<n)
    {
        a=2*a;
        if(a<n)
        {
            cout<<a<<endl;
    }}
    return 0;
}
