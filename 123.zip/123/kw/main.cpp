#include <iostream>
#include <time.h>
#include <stdio.h>
#include <stdlib.h>

using namespace std;

double a, h, pole;

int main()
{
    cout << "Podaj Podstawe Kwadrata"<<endl;
    cin >> a;
    pole = a*a;
    cout<<"Pole to:"<<pole;
    return 0;
}
