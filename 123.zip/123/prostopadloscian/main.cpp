#include <iostream>
#include <time.h>
#include <stdio.h>
#include <stdlib.h>

using namespace std;

double a, h, pole;

int main()
{
    cout << "Podaj Podstawe Rownolegloboku"<<endl;
    cin >> a;
    cout << "Podaj Wysokosc Rownolegloboku"<<endl;
    cin >> h;
    pole = a*h;
    cout<<"Pole to:"<<pole;
    return 0;
}
