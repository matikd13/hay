#include <iostream>

using namespace std;

int main()
{
    int a,b;
    cin>>b>>a;
    a=a-1;
    for(int i=0;i<=a;i++)
    {
        for(int j=0;j<b;j++)
        {
            cout<<"#";

        }
        cout<<endl;
    }

    return 0;
}
