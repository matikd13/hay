#include <iostream>
#include <time.h>
#include <stdio.h>
#include <stdlib.h>

using namespace std;

double a, h, pole;

int main()
{
    cout << "Podaj Podstawe Trojkata"<<endl;
    cin >> a;
    cout << "Podaj Wysokosc Trojkata"<<endl;
    cin >> h;
    pole = a*h/2;
    cout<<"Pole to:"<<pole;
    return 0;
}
