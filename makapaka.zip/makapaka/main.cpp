#include <iostream>

using namespace std;

int main()
{
    string loginwer = "matikd";
    string loginwer1 = "gosc";
    string login;
    int haslo;
    int haslower = 123456;
    cout<< "Podaj Login: ";
    cin>> login;
    if(login == loginwer)
    {
        cout<<endl<< "Podaj Haslo: ";
        cin>> haslo;
        if(haslo == haslower)
        {
            while(1)
            {
            cout<<"111001011000101";
            }
        }
        else
        {
            cout<<"Odmowa Dostepu";
        }
    }
    else if(loginwer1 == login)
    {
        cout<<"I co zrobisz?"<<endl<<endl;
        cout<<"nic nie zrobisz";
    }
    else
    {
        cout<<"Nie istnieje taki uzytkownik";
    }
}
