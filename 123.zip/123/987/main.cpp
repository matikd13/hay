#include <iostream>

using namespace std;

int main()
{
    float d,a,c=1,b,win=0;
    while(c=1)
    {
        b=a;
        cin>>a;
        if(a==-1)
        {
            cout<<win;
            break;
        }
        else if(a>b)
        {
            win=win+1;
        }
    }

    return 0;
}
