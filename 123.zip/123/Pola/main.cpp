#include <iostream>
#include <time.h>
#include <stdio.h>
#include <stdlib.h>

using namespace std;


int main()
{
cout << "Podaj Podstawe Trojkata"<<troj(2,5)<<endl;

    cout << "Podaj Wysokosc Trojkata"<<troj(2,5)<<endl;


    return 0;
}

double troj(double a, double h)
{

/*double pole;
pole = a*h/2;
    cout<<"Pole to:"<<pole<<endl;
    */return a;
}
