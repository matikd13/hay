#include <iostream>
using namespace std;
int main() {
	char x;
	int suma = 0;
	do {
		cin >> x;
		if (x == 'P')
			suma++;
	} while (x!='K');
	cout << suma;
	return 0;
}