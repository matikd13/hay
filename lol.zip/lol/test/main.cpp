#include <iostream>
#include <cstdlib>
using namespace std;

int main()
{
    int a;
    while(1)
    {
        cin >> a;
        if(a==36)
        {
            break;
        }
        else
        {

            cout << (char)a<<endl;

        }
    }
    system("PAUSE");
    return 0;
}
