#include <iostream>

using namespace std;

int main()
{
    float i=0,m2,m,l,n;
    cin>>n;
    cin>>m;
    n=n-1;
    m2=m;
    while(i<n)
    {
        i++;
        cin>>l;
        if(l>m)
        {
            m=l;
        }
        else if(l<m)
        {
            m2=l;
        }
    }
    cout<<"najwieksza: "<<m<<endl<<"najmniejsza: "<<m2;


    return 0;
}
